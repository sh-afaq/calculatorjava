

function display(val) {
document.getElementById("box").value+= val;

}
 
function solve()
 {
	 let x = document.getElementById("box").value
     let y = eval(x)
     document.getElementById("box").value = y
            
 }
 function clr()
 {
	 document.getElementById("box").value = ""
      
 }




